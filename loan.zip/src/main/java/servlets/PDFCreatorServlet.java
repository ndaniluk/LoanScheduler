package servlets;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PDFCreatorServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response){

    }
}
